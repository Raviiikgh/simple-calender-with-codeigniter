<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calender extends CI_Controller {
	
	function index($year = null, $month = null){
		
		if(!$year){
			$year = date('Y');
		}

		if(!$month){
			$month = date('m');
		}

		$this->load->model('calender_model');

		if ($this->input->post('ajax')) {
			$this->calender_model->add_data_in_calender($year,$month);
		}

		$data['calender'] = $this->calender_model->generate($year, $month);
		$this->load->view('calender_view', $data);
	}
}