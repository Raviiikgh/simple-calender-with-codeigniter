<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>My Calender </title>
	<style type="text/css">
	.calender{
		font-family: verdana;
		font-size: 14px;
	}
	table.calender{
		margin: auto;
		border-collapse:collapse; 
	}
	.calender .days td{
		width:80px; height:80px; padding:4px; border: 1px solid #999; vertical-align: top; background-color: #efefef;
 	}
 	.calender .days td:hover{
		background-color: #FFF;
		cursor: pointer;
	}
	.calender .highlight{
		font-weight: bold;
	}
	</style>
	<script src="<?php echo base_url();?>asset/jquery.min.js" type="text/javascript"></script>
</head>
<body>
	<?php echo $calender; ?>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('.day').click(function(){
			var input_day = $(this).find('.day_num').html();
			var input_data = $(this).find('.content').html();
			var new_data = prompt('Enter Your Stuff Here', input_data);
			
			if(new_data){
				$.ajax({
					url : window.location,
					type : "POST",
					data : {
						day : input_day,
						data : new_data,
						ajax : 1
					},
					success : function(msg){
						location.reload();
					}
				});
			}
			
		});
	});
	</script>
</body>
</html>